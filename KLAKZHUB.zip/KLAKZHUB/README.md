# KLAKZHUB

WeAreDevs Library tarzından ilham alan, koyu temalı geliştirici kaynak kütüphanesi. Next.js App Router, TypeScript, Tailwind CSS v4 ve Lucide ikonlarıyla hazırlanmıştır.

## Gereksinimler
- Node.js 20.9 veya üzeri (LTS önerilir)
- npm

## Kurulum (Windows)
1. ZIP dosyasını çıkar.
2. KLAKZHUB klasörünü aç.
3. Klasör içinde terminal / PowerShell aç.
4. Komutları sırayla çalıştır:

```bash
npm install
npm run dev
```

5. Tarayıcıda http://localhost:3000 adresine git.

## Üretim derlemesi

```bash
npm run build
npm start
```

## Özellikler
- Responsive koyu tema arayüzü
- Kütüphane araması
- Kategori, tür ve sıralama filtreleri
- İçerik kartları ve dinamik detay sayfaları
- Demo içerik ekleme/silme paneli (`/admin`)
- Örnek Roblox, Minecraft ve geliştirici araçları içerikleri

## Önemli notlar
- İçerikler şu an `src/lib/resources.ts` dosyasında örnek veri olarak tutulur.
- Admin paneli gerçek giriş sistemi veya kalıcı veritabanı içermez; demo değişiklikleri sayfa yenilenince sıfırlanır.
- İnternete yayınlamadan önce kimlik doğrulama, yetkilendirme, veritabanı, rate limiting ve sunucu tarafı doğrulama ekle.
- Harici scriptleri çalıştırmadan önce kodu ve lisansını incele. Yetkisiz erişim veya platform güvenliğini aşmaya yönelik özellikler ekleme.

## Proje yapısı

```text
src/
  app/
    admin/page.tsx
    library/[id]/page.tsx
    globals.css
    layout.tsx
    page.tsx
  components/
    AdminPanel.tsx
    Hub.tsx
  lib/
    resources.ts
```
