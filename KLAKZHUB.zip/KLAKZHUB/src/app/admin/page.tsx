import Link from "next/link";
import AdminPanel from "@/components/AdminPanel";
import { ArrowLeft, Braces } from "lucide-react";

export default function AdminPage() {
  return <main className="min-h-screen py-8 sm:py-12"><div className="shell max-w-5xl">
    <Link href="/" className="mb-8 inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white"><ArrowLeft size={16}/> Siteye dön</Link>
    <div className="mb-8 flex items-center gap-4"><span className="grid h-14 w-14 place-items-center rounded-2xl bg-violet-500/15 text-violet-200"><Braces size={28}/></span><div><p className="text-xs font-bold uppercase tracking-[.2em] text-violet-300">KLAKZHUB CMS</p><h1 className="mt-1 text-3xl font-black">Yönetim paneli</h1><p className="mt-2 text-sm text-slate-400">Demo içerik yönetimi · Bu sürümde değişiklikler tarayıcı belleğinde tutulur.</p></div></div>
    <AdminPanel/>
  </div></main>;
}