import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "KLAKZHUB — Developer Library",
  description: "Discover scripts, tools, mods, and developer resources.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="tr"><body>{children}</body></html>;
}