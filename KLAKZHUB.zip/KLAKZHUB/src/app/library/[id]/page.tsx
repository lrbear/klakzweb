import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowDownToLine, Braces, CheckCircle2, Code2, ShieldCheck } from "lucide-react";
import { resources } from "@/lib/resources";

export function generateStaticParams() { return resources.map((item) => ({ id: item.id })); }

export default async function ResourceDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const item = resources.find((r) => r.id === id);
  if (!item) notFound();
  return <main className="min-h-screen py-8 sm:py-12"><div className="shell max-w-4xl">
    <Link href="/#library" className="mb-8 inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white"><ArrowLeft size={16}/> Kütüphaneye dön</Link>
    <div className="glass rounded-3xl p-6 sm:p-10">
      <div className="mb-6 flex flex-wrap gap-2"><span className="rounded-full border border-violet-400/20 bg-violet-500/10 px-3 py-1 text-xs text-violet-200">{item.category}</span><span className="rounded-full border border-white/10 px-3 py-1 text-xs text-slate-300">{item.kind}</span></div>
      <div className="flex flex-col gap-5 sm:flex-row sm:items-start"><span className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl border border-violet-400/20 bg-violet-500/10 text-violet-200"><Braces size={31}/></span><div><h1 className="text-3xl font-black sm:text-4xl">{item.title}</h1><p className="mt-3 max-w-2xl leading-7 text-slate-400">{item.description}</p><p className="mt-4 text-xs text-slate-500">Hazırlayan: {item.author} · Güncelleme: {item.updated}</p></div></div>
      <div className="my-8 grid grid-cols-2 gap-3 sm:grid-cols-4">{[["Oyun / platform",item.game],["Dil",item.language],["Sürüm",item.version],["Görüntülenme",item.downloads]].map(([label,value])=><div key={label} className="rounded-xl border border-white/[.07] bg-[#090c14] p-4"><p className="text-xs text-slate-500">{label}</p><p className="mt-2 font-semibold text-slate-200">{value}</p></div>)}</div>
      <div className="mb-8"><h2 className="mb-3 text-lg font-bold">Açıklama</h2><p className="leading-7 text-slate-300">{item.content}</p></div>
      <div className="mb-8"><h2 className="mb-3 text-lg font-bold">Etiketler</h2><div className="flex flex-wrap gap-2">{item.tags.map(t=><span key={t} className="rounded-lg bg-white/[.05] px-3 py-2 text-sm text-slate-300">#{t}</span>)}</div></div>
      <div className="rounded-2xl border border-amber-300/15 bg-amber-300/[.05] p-4"><div className="flex gap-3"><ShieldCheck className="mt-0.5 shrink-0 text-amber-200"/><div><p className="font-semibold text-amber-100">Kullanmadan önce kontrol et</p><p className="mt-1 text-sm leading-6 text-slate-400">Bu başlangıç projesinde örnek içerik gösterilir. Harici indirme dosyası bağlı değildir. Kaynak kodunu, lisansı ve izinlerini incelemeden çalıştırma.</p></div></div></div>
      <Link href="/#library" className="btn-primary mt-7 inline-flex items-center gap-2"><ArrowLeft size={16}/> Diğer kaynaklar</Link>
    </div>
  </div></main>;
}