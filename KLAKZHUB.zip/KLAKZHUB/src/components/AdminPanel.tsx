 "use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Plus, Search, Trash2, ExternalLink, Info, CheckCircle2 } from "lucide-react";
import { resources as seed, type Resource } from "@/lib/resources";

export default function AdminPanel() {
  const [items, setItems] = useState<Resource[]>(seed);
  const [query, setQuery] = useState("");
  const [message, setMessage] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Developer Tools");
  const [kind, setKind] = useState<Resource["kind"]>("Tool");
  const [language, setLanguage] = useState("JavaScript");
  const visible = useMemo(() => items.filter(i => (i.title+" "+i.category).toLocaleLowerCase("tr").includes(query.toLocaleLowerCase("tr"))), [items, query]);

  function addResource(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim() || !description.trim()) { setMessage("Başlık ve açıklama alanlarını doldur."); return; }
    const id = title.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"") + "-" + Date.now().toString().slice(-5);
    const item: Resource = { id, title:title.trim(), description:description.trim(), category, game:category==="Roblox"?"Roblox Studio":category==="Minecraft"?"Minecraft":"Web", language:language.trim()||"Belirtilmedi", version:"1.0.0", author:"Admin", tags:["Community","New"], kind, downloads:"0", updated:"Şimdi", content:description.trim() };
    setItems(prev=>[item,...prev]); setTitle(""); setDescription(""); setMessage("Kaynak demo listesine eklendi. Yenileme sonrası kaybolur.");
  }
  function remove(id: string) { setItems(prev=>prev.filter(i=>i.id!==id)); setMessage("Kaynak demo listesinden kaldırıldı."); }

  return <div className="space-y-6">
    <div className="grid gap-4 sm:grid-cols-3">{[{label:"Toplam kaynak",value:items.length},{label:"Kategoriler",value:new Set(items.map(i=>i.category)).size},{label:"İçerik türleri",value:new Set(items.map(i=>i.kind)).size}].map(x=><div key={x.label} className="glass rounded-2xl p-5"><p className="text-sm text-slate-400">{x.label}</p><p className="mt-2 text-3xl font-black gradient-text">{x.value}</p></div>)}</div>
    <div className="glass rounded-2xl p-5 sm:p-7"><div className="mb-5 flex items-center gap-2"><Plus size={19} className="text-violet-300"/><h2 className="text-xl font-bold">Yeni kaynak ekle</h2></div>
      <form onSubmit={addResource} className="grid gap-4 md:grid-cols-2">
        <label className="text-sm text-slate-300">Başlık<input className="field mt-2" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Örn. TypeScript yardımcı aracı" maxLength={90}/></label>
        <label className="text-sm text-slate-300">Kategori<select className="field mt-2" value={category} onChange={e=>setCategory(e.target.value)}>{["Roblox","Minecraft","Developer Tools","Guides"].map(c=><option key={c}>{c}</option>)}</select></label>
        <label className="text-sm text-slate-300">Tür<select className="field mt-2" value={kind} onChange={e=>setKind(e.target.value)}>{["Script","Tool","Mod","Guide"].map(c=><option key={c}>{c}</option>)}</select></label>
        <label className="text-sm text-slate-300">Dil / teknoloji<input className="field mt-2" value={language} onChange={e=>setLanguage(e.target.value)} placeholder="JavaScript, Luau..."/></label>
        <label className="text-sm text-slate-300 md:col-span-2">Açıklama<textarea className="field mt-2 min-h-24 resize-y" value={description} onChange={e=>setDescription(e.target.value)} placeholder="Kaynağın ne yaptığını kısaca açıkla." maxLength={500}/></label>
        <div className="flex flex-wrap items-center gap-3 md:col-span-2"><button className="btn-primary inline-flex items-center gap-2" type="submit"><Plus size={16}/> Kaynağı ekle</button>{message && <p role="status" className="text-sm text-emerald-200">{message}</p>}</div>
      </form>
    </div>
    <div className="glass rounded-2xl p-5 sm:p-7"><div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-center"><h2 className="text-xl font-bold">Kaynaklar</h2><label className="relative block sm:w-64"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"/><input className="field py-2 pl-9" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Kaynak ara..."/></label></div>
      <div className="space-y-3">{visible.map(item=><div key={item.id} className="flex flex-col justify-between gap-3 rounded-xl border border-white/[.07] bg-[#0a0d15] p-4 sm:flex-row sm:items-center"><div><p className="font-semibold">{item.title}</p><p className="mt-1 text-xs text-slate-500">{item.category} · {item.kind} · {item.language}</p></div><div className="flex items-center gap-2"><Link href={`/library/${item.id}`} className="btn-secondary inline-flex items-center gap-2 text-xs"><ExternalLink size={14}/> Görüntüle</Link><button onClick={()=>remove(item.id)} className="rounded-lg border border-rose-400/20 p-2 text-rose-200 hover:bg-rose-400/10" aria-label={`${item.title} kaynağını kaldır`}><Trash2 size={15}/></button></div></div>)}</div>
      {!visible.length && <p className="py-8 text-center text-sm text-slate-500">Eşleşen kaynak bulunamadı.</p>}
    </div>
    <div className="rounded-2xl border border-amber-300/20 bg-amber-300/[.05] p-4 text-sm leading-6 text-slate-400"><Info size={17} className="mb-2 text-amber-200"/><strong className="text-amber-100">Yayınlamadan önce:</strong> Bu panel prototip amaçlıdır; gerçek kimlik doğrulama, veritabanı ve rol kontrolü içermez. Üretimde admin işlemlerini sunucu tarafında doğrula ve kalıcı veritabanı bağla. Buradaki ekleme/silme işlemleri yalnızca açık sekmedeki demo listesinde geçerlidir.</div>
  </div>;
}