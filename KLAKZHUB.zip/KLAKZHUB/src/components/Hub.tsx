 "use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { ArrowDownToLine, ArrowRight, BookOpen, Boxes, Braces, Check, ChevronDown, Code2, Compass, Filter, Gamepad2, Github, Menu, Search, ShieldCheck, Sparkles, Terminal, X } from "lucide-react";
import { categories, resources, type Resource } from "@/lib/resources";

function Logo() {
  return <Link href="/" className="flex items-center gap-3 font-black tracking-tight text-lg"><span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-black shadow-lg shadow-violet-900/30"><Braces size={23} strokeWidth={2.8}/></span><span>KLAKZ<span className="text-violet-300">HUB</span></span></Link>;
}

function ResourceCard({ item }: { item: Resource }) {
  const Icon = item.kind === "Tool" ? Terminal : item.kind === "Mod" ? Boxes : item.kind === "Guide" ? BookOpen : Code2;
  return <article className="glass card-hover flex flex-col rounded-2xl p-5">
    <div className="mb-5 flex items-start justify-between gap-3">
      <span className="grid h-12 w-12 place-items-center rounded-xl border border-violet-400/20 bg-violet-500/10 text-violet-200"><Icon size={23}/></span>
      <div className="flex flex-wrap justify-end gap-2"><span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-slate-300">{item.kind}</span>{item.featured && <span className="rounded-full border border-amber-300/20 bg-amber-300/10 px-2.5 py-1 text-xs text-amber-200">Öne çıkan</span>}</div>
    </div>
    <p className="mb-2 text-xs font-semibold uppercase tracking-[.15em] text-cyan-200/80">{item.category} <span className="text-slate-600">/</span> {item.game}</p>
    <h3 className="mb-2 text-lg font-bold text-white">{item.title}</h3>
    <p className="mb-5 min-h-[48px] text-sm leading-6 text-slate-400">{item.description}</p>
    <div className="mb-5 flex flex-wrap gap-2">{item.tags.map(tag => <span key={tag} className="rounded-md bg-[#090c14] px-2 py-1 text-xs text-slate-400">#{tag}</span>)}</div>
    <div className="mt-auto flex items-center justify-between border-t border-white/[.07] pt-4">
      <span className="text-xs text-slate-500">{item.language} · v{item.version}</span>
      <Link href={`/library/${item.id}`} className="inline-flex items-center gap-1.5 text-sm font-semibold text-violet-300 hover:text-cyan-200">Detaylar <ArrowRight size={15}/></Link>
    </div>
  </article>;
}

export default function Hub() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Tümü");
  const [kind, setKind] = useState("Tüm türler");
  const [sort, setSort] = useState("Öne çıkanlar");
  const [mobileOpen, setMobileOpen] = useState(false);
  const filtered = useMemo(() => {
    let list = resources.filter(r => {
      const q = query.toLocaleLowerCase("tr");
      const matchesQuery = !q || [r.title,r.description,r.category,r.game,r.language,...r.tags].join(" ").toLocaleLowerCase("tr").includes(q);
      const matchesCategory = category === "Tümü" || r.category === category || (category === "Guides" && r.kind === "Guide");
      const matchesKind = kind === "Tüm türler" || r.kind === kind;
      return matchesQuery && matchesCategory && matchesKind;
    });
    if (sort === "A-Z") list = [...list].sort((a,b)=>a.title.localeCompare(b.title));
    if (sort === "En yeni") list = [...list].reverse();
    if (sort === "Öne çıkanlar") list = [...list].sort((a,b)=>Number(Boolean(b.featured))-Number(Boolean(a.featured)));
    return list;
  }, [query, category, kind, sort]);

  return <main className="min-h-screen overflow-hidden">
    <div className="pointer-events-none absolute inset-x-0 top-0 h-[580px] soft-grid opacity-70"/>
    <header className="relative z-10 border-b border-white/[.07]">
      <div className="shell flex h-[76px] items-center justify-between">
        <Logo/>
        <nav className="hidden items-center gap-8 text-sm text-slate-400 md:flex"><a className="hover:text-white" href="#library">Kütüphane</a><a className="hover:text-white" href="#categories">Kategoriler</a><a className="hover:text-white" href="#about">Hakkında</a><Link className="hover:text-white" href="/admin">Yönetim</Link></nav>
        <div className="hidden items-center gap-3 md:flex"><a href="#library" className="btn-secondary inline-flex items-center gap-2 text-sm"><Search size={15}/> İçerik ara</a><a href="#library" className="btn-primary inline-flex items-center gap-2 text-sm">Keşfet <ArrowRight size={15}/></a></div>
        <button className="rounded-lg border border-white/10 p-2 md:hidden" onClick={()=>setMobileOpen(!mobileOpen)} aria-label="Menüyü aç/kapat">{mobileOpen?<X/>:<Menu/>}</button>
      </div>
      {mobileOpen && <div className="shell flex flex-col gap-4 pb-5 text-sm text-slate-300 md:hidden"><a href="#library" onClick={()=>setMobileOpen(false)}>Kütüphane</a><a href="#categories" onClick={()=>setMobileOpen(false)}>Kategoriler</a><Link href="/admin">Yönetim paneli</Link></div>}
    </header>

    <section className="shell relative z-[1] grid items-center gap-12 pb-20 pt-16 md:grid-cols-[1.15fr_.85fr] md:pb-24 md:pt-24">
      <div>
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-violet-400/20 bg-violet-400/[.07] px-3 py-1.5 text-xs font-semibold text-violet-200"><Sparkles size={14}/> Geliştiriciler için topluluk kütüphanesi</div>
        <h1 className="max-w-2xl text-4xl font-black leading-[1.08] tracking-tight sm:text-5xl md:text-6xl">Kodunu keşfet.<br/><span className="gradient-text">Sınırlarını genişlet.</span></h1>
        <p className="mt-6 max-w-xl text-base leading-7 text-slate-400 md:text-lg">Scriptler, modlar, araçlar ve geliştirici rehberleri tek yerde. Projende kullanabileceğin kaynakları keşfet, öğren ve kendi üretimini paylaşmaya hazırlan.</p>
        <div className="mt-8 flex flex-wrap gap-3"><a className="btn-primary inline-flex items-center gap-2" href="#library">Kütüphaneyi keşfet <ArrowRight size={16}/></a><a className="btn-secondary inline-flex items-center gap-2" href="#about"><Compass size={16}/> Nasıl çalışır?</a></div>
        <div className="mt-9 flex flex-wrap gap-x-6 gap-y-3 text-xs text-slate-500"><span className="inline-flex items-center gap-2"><ShieldCheck size={15} className="text-emerald-300"/> Güvenliği öncele</span><span className="inline-flex items-center gap-2"><Check size={15} className="text-cyan-300"/> Kategorilere göre keşfet</span><span className="inline-flex items-center gap-2"><Code2 size={15} className="text-violet-300"/> Geliştirici odaklı</span></div>
      </div>
      <div className="relative mx-auto w-full max-w-md">
        <div className="absolute -inset-8 rounded-full bg-violet-600/15 blur-3xl"/>
        <div className="glass relative rounded-3xl p-5 shadow-2xl shadow-black/40 sm:p-6">
          <div className="mb-6 flex items-center justify-between"><div className="flex gap-1.5"><i className="h-2.5 w-2.5 rounded-full bg-rose-400"/><i className="h-2.5 w-2.5 rounded-full bg-amber-300"/><i className="h-2.5 w-2.5 rounded-full bg-emerald-300"/></div><span className="font-mono text-xs text-slate-500">klakzhub / explorer</span><Terminal size={16} className="text-violet-300"/></div>
          <div className="rounded-2xl border border-white/[.07] bg-[#090c14] p-4">
            <div className="mb-4 flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-violet-500/15 text-violet-200"><Braces/></span><div><p className="font-semibold">Developer Library</p><p className="mt-1 text-xs text-slate-500">Kaynaklar · Rehberler · Araçlar</p></div><span className="ml-auto h-2 w-2 rounded-full bg-emerald-300"/></div>
            {["roblox-ui-kit.ts","fabric-mod-guide.md","json-formatter.ts"].map((f,i)=><div key={f} className="mb-2 flex items-center gap-3 rounded-xl border border-white/[.05] bg-white/[.025] p-3"><Code2 size={16} className={i===1?"text-cyan-200":"text-violet-300"}/><span className="font-mono text-xs text-slate-300">{f}</span><span className="ml-auto text-[10px] text-slate-600">{i===0?"LUAU":i===1?"GUIDE":"TOOL"}</span></div>)}
            <div className="mt-4 flex items-center justify-between rounded-xl bg-violet-500/10 p-3"><span className="text-xs text-violet-100">Yeni bir şey keşfetmeye hazır mısın?</span><ArrowRight size={16} className="text-violet-200"/></div>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-3">{[["06","Kaynak örneği"],["04","Kategori"],["∞","Fikir"]].map(([n,t])=><div key={t} className="rounded-xl border border-white/[.06] bg-white/[.025] p-3"><p className="text-xl font-black gradient-text">{n}</p><p className="mt-1 text-[10px] text-slate-500">{t}</p></div>)}</div>
        </div>
      </div>
    </section>

    <section id="categories" className="shell pb-16">
      <div className="mb-6 flex items-end justify-between gap-4"><div><p className="mb-2 text-xs font-bold uppercase tracking-[.2em] text-violet-300">Kategoriler</p><h2 className="text-2xl font-bold">İlgi alanına göre keşfet</h2></div><span className="hidden text-sm text-slate-500 sm:block">Bir kategori seçerek listeyi filtrele</span></div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">{[{name:"Roblox",desc:"Studio kaynakları",icon:Gamepad2},{name:"Minecraft",desc:"Modlar ve rehberler",icon:Boxes},{name:"Developer Tools",desc:"Kod araçları",icon:Terminal},{name:"Guides",desc:"Öğren ve geliştir",icon:BookOpen}].map(({name,desc,icon:Icon})=><button key={name} onClick={()=>{setCategory(name);document.getElementById("library")?.scrollIntoView({behavior:"smooth"});}} className={`glass card-hover rounded-2xl p-4 text-left ${category===name?"border-violet-400/60 bg-violet-500/10":""}`}><Icon size={21} className="mb-4 text-violet-200"/><p className="font-semibold">{name}</p><p className="mt-1 text-xs text-slate-500">{desc}</p></button>)}</div>
    </section>

    <section id="library" className="relative border-y border-white/[.06] bg-[#0c0f17] py-16 md:py-20">
      <div className="shell">
        <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><p className="mb-2 text-xs font-bold uppercase tracking-[.2em] text-cyan-200">Kaynak koleksiyonu</p><h2 className="text-3xl font-black">Kütüphane<span className="text-violet-300">.</span></h2><p className="mt-2 text-sm text-slate-400">İçeriği ara, filtrele ve ayrıntılarını incele.</p></div><div className="flex items-center gap-2 text-sm text-slate-500"><Boxes size={17}/>{filtered.length} kaynak gösteriliyor</div></div>
        <div className="glass mb-7 grid gap-3 rounded-2xl p-3 md:grid-cols-[1fr_190px_170px]">
          <label className="relative block"><Search size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500"/><input className="field pl-10" value={query} onChange={e=>setQuery(e.target.value)} placeholder="İsim, oyun, etiket veya dil ara..."/></label>
          <label className="relative"><Filter size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500"/><select className="field appearance-none pl-9 pr-8" value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(c=><option key={c}>{c}</option>)}</select><ChevronDown size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-500"/></label>
          <label className="relative"><select className="field appearance-none pr-8" value={kind} onChange={e=>setKind(e.target.value)}>{["Tüm türler","Script","Tool","Mod","Guide"].map(c=><option key={c}>{c}</option>)}</select><ChevronDown size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-500"/></label>
        </div>
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div className="flex flex-wrap gap-2">{categories.map(c=><button key={c} onClick={()=>setCategory(c)} className={`rounded-full border px-3 py-1.5 text-xs transition ${category===c?"border-violet-400/50 bg-violet-500/15 text-violet-100":"border-white/10 text-slate-400 hover:border-white/20 hover:text-white"}`}>{c}</button>)}</div><select className="rounded-lg border border-white/10 bg-[#10131d] px-3 py-2 text-xs text-slate-300 outline-none" value={sort} onChange={e=>setSort(e.target.value)}><option>Öne çıkanlar</option><option>En yeni</option><option>A-Z</option></select></div>
        {filtered.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{filtered.map(item=><ResourceCard key={item.id} item={item}/>)}</div> : <div className="glass rounded-2xl p-12 text-center"><Search className="mx-auto mb-3 text-slate-500"/><h3 className="font-bold">Sonuç bulunamadı</h3><p className="mt-2 text-sm text-slate-500">Arama kelimesini veya filtreleri değiştirmeyi dene.</p><button className="btn-secondary mt-5" onClick={()=>{setQuery("");setCategory("Tümü");setKind("Tüm türler");}}>Filtreleri temizle</button></div>}
      </div>
    </section>

    <section id="about" className="shell py-16 md:py-20"><div className="glass grid gap-8 rounded-3xl p-7 md:grid-cols-[1fr_auto] md:items-center md:p-10"><div><div className="mb-3 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[.18em] text-emerald-200"><ShieldCheck size={15}/> Güvenli keşif</div><h2 className="max-w-2xl text-2xl font-black md:text-3xl">Önce incele. Sonra kullan. <span className="gradient-text">Daha iyi üret.</span></h2><p className="mt-3 max-w-2xl text-sm leading-6 text-slate-400">KLAKZHUB, geliştirici kaynaklarını bulmayı kolaylaştırmak için tasarlandı. Kaynağını bilmediğin kodları çalıştırmadan önce incele; platform kurallarına ve lisanslara uy.</p></div><a href="#library" className="btn-primary inline-flex w-fit items-center gap-2">Kaynakları görüntüle <ArrowRight size={16}/></a></div></section>

    <footer className="border-t border-white/[.07] py-7"><div className="shell flex flex-col items-start justify-between gap-4 text-xs text-slate-500 sm:flex-row sm:items-center"><Logo/><p>© 2026 KLAKZHUB · Topluluk için, geliştiricilerle.</p><Link href="/admin" className="hover:text-violet-300">Yönetim paneli</Link></div></footer>
  </main>;
}